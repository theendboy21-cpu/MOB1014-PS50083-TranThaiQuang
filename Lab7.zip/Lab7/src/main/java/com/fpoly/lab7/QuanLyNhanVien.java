/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fpoly.lab7;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
/**
 *
 * @author Lenovo
 */



public class QuanLyNhanVien {
    public static void main(String[] args) {
        // Khai báo danh sách chứa nhân viên theo yêu cầu
        List<Employee> list = new ArrayList<>();

        // Thêm 5 nhân viên theo bảng Dữ liệu mẫu (ở hình trước)
        list.add(new FullTimeEmployee("FT01", "Nguyen Van An", 12000000));
        list.add(new PartTimeEmployee("PT01", "Tran Thị Binh", 80, 50000));
        list.add(new FullTimeEmployee("FT02", "Le Van Cuong", 15500000));
        list.add(new PartTimeEmployee("PT02", "Pham Thi Dung", 120, 60000));
        list.add(new PartTimeEmployee("PT03", "Hoang Van Em", 200, 90000));

        // 1. Duyệt danh sách, in toString() và lương của từng nhân viên
        System.out.println("=== DANH SACH NHAN VIEN ===");
        for (Employee e : list) {
            // Tính đa hình: e.getSalary() tự động gọi đúng phương thức của lớp con thực tế
            System.out.printf("%s -> Luong: %.0f\n", e.toString(), e.getSalary());
        }

        // 2. Tính và in tổng quỹ lương
        double totalSalary = 0;
        for (Employee e : list) {
            totalSalary += e.getSalary();
        }
        System.out.printf("Tong quy luong: %.0f\n", totalSalary);

        // 3. Tìm và in nhân viên có lương cao nhất
        Employee maxSalaryEmployee = list.get(0);
        for (Employee e : list) {
            if (e.getSalary() > maxSalaryEmployee.getSalary()) {
                maxSalaryEmployee = e;
            }
        }
        System.out.printf("Nhan vien luong cao nhat: %s -> Luong: %.0f\n", 
                maxSalaryEmployee.toString(), maxSalaryEmployee.getSalary());

        // 4. Sắp xếp danh sách theo lương giảm dần bằng Collections.sort() với Comparator
        Collections.sort(list, new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                // Sắp xếp giảm dần: đảo thứ tự tham số truyền vào Double.compare(b, a)
                return Double.compare(e2.getSalary(), e1.getSalary());
            }
        });

        // Xuất lại danh sách sau khi đã sắp xếp
        System.out.println("=== SAP XEP THEO LUONG GIAM DAN ===");
        for (Employee e : list) {
            System.out.printf("%s -> Luong: %.0f\n", e.toString(), e.getSalary());
        }
    }
}

