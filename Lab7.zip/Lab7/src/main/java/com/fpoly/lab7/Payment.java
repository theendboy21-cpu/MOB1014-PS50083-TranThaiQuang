/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fpoly.lab7;

/**
 *
 * @author Lenovo
 */


public interface Payment {
    // Thuộc tính trong interface mặc định là public static final (hằng số)
    double TAX = 0.1;

    // Phương thức trong interface mặc định là public abstract
    double pay(double amount);
}
 

