/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fpoly.lab7;

/**
 *
 * @author Lenovo
 */


public class PartTimeEmployee extends Employee {
    // Thuộc tính private (- trong UML)
    private int workHours;
    private double salaryPerHour;

    // Hàm tạo đầy đủ tham số
    public PartTimeEmployee(String id, String name, int workHours, double salaryPerHour) {
        super(id, name); // Gọi constructor của lớp cha Employee
        this.workHours = workHours;
        this.salaryPerHour = salaryPerHour;
    }

    // Getter và Setter cho workHours
    public int getWorkHours() {
        return workHours;
    }

    public void setWorkHours(int workHours) {
        this.workHours = workHours;
    }

    // Getter và Setter cho salaryPerHour
    public double getSalaryPerHour() {
        return salaryPerHour;
    }

    public void setSalaryPerHour(double salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }

    // Công thức tính lương nhân viên bán thời gian = workHours * salaryPerHour
    @Override
    public double getSalary() {
        return this.workHours * this.salaryPerHour;
    }

    // Ghi đè phương thức toString để hiển thị thông tin
    @Override
    public String toString() {
        return String.format("PartTime [ID: %s, Name: %s, Work Hours: %d, Rate: %.1f, Total Salary: %.1f]", 
                id, name, workHours, salaryPerHour, getSalary());
    }
}
