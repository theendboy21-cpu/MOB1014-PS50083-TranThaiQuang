/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fpoly.lab7;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */


public class ThanhToanDemo {
    public static void main(String[] args) {
        // 1. Khai báo mảng giá trị đơn hàng
        double[] donHang = {100000, 250000, 1000000};

        // 2. Khai báo List<Payment> chứa các hình thức thanh toán đa hình
        List<Payment> methods = new ArrayList<>();
        methods.add(new CashPayment()); // phần tử index 0: Tiền mặt
        methods.add(new CardPayment()); // phần tử index 1: Thẻ

        // 3. Duyệt qua từng đơn hàng và in số tiền phải thanh toán theo mẫu
        for (double price : donHang) {
            // Lấy kết quả thanh toán từ từng đối tượng cụ thể trong danh sách
            double cashAmount = methods.get(0).pay(price);
            double cardAmount = methods.get(1).pay(price);

            // Sử dụng printf với %.0f để tránh lỗi sai số biểu diễn của kiểu số thực (double)
            System.out.printf("Don hang %.0f: Tien mat = %.0f | The = %.0f\n", 
                    price, cashAmount, cardAmount);
        }
    }
}
